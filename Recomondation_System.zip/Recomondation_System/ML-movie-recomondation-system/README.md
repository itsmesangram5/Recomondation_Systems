# ML-movie-recomondation-system
this is content based movie recommendation system

# what  is content based recomondation system
We are encounter many serch engine in daily life like amazon,google,netflix,hotstar etc.
They have diffrent type of catagory and content, so they will suggest you diffrent kind of data to.But how ?

here comes ML in scean ,see ML has various method to calculate datasets, and content based is one of them .
in content based data system , contain csv file which has all type of data like catagory,maker,brand etc.
so model will calculate all things and then project point in multi dimensnion. we cant imagine because there will lots of dimensions due to multipl features.
so by using similarity between points we can identify which point is similar to which one.after identifysuccesfully we just need user reqirement.

like in this programm if user enter any movie he likes then it will print most similar movies so user will defenetly watch ,and their business will grow.

for other technical defination or explanation i already attach comments so read it before you remove.
